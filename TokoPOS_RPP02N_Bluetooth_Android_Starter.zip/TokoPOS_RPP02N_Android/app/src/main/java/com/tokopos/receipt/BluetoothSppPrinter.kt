package com.tokopos.receipt

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.OutputStream
import java.util.UUID

/**
 * RPP02N commonly exposes Classic Bluetooth SPP. Pair it in Android Settings
 * first (device name often RPP02N; PIN commonly 0000), then connect by address.
 * Confirm exact interface/firmware on the physical unit.
 */
class BluetoothSppPrinter {
    companion object {
        // Standard Serial Port Profile UUID used by many ESC/POS Bluetooth printers.
        val SPP_UUID: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
    }

    private var socket: BluetoothSocket? = null
    private var output: OutputStream? = null

    @SuppressLint("MissingPermission")
    suspend fun pairedPrinters(adapter: BluetoothAdapter): Result<List<BluetoothDevice>> =
        withContext(Dispatchers.IO) {
            runCatching { adapter.bondedDevices.toList().sortedBy { it.name ?: it.address } }
        }

    @SuppressLint("MissingPermission")
    suspend fun connect(device: BluetoothDevice): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            closeInternal()
            val s = device.createRfcommSocketToServiceRecord(SPP_UUID)
            s.connect()
            socket = s
            output = s.outputStream
        }
    }

    suspend fun print(bytes: ByteArray): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            val stream = output ?: error("Printer belum tersambung")
            stream.write(bytes)
            stream.flush()
        }
    }

    suspend fun disconnect() = withContext(Dispatchers.IO) { closeInternal() }

    private fun closeInternal() {
        runCatching { output?.close() }
        runCatching { socket?.close() }
        output = null
        socket = null
    }

    fun isConnected(): Boolean = socket?.isConnected == true
}
