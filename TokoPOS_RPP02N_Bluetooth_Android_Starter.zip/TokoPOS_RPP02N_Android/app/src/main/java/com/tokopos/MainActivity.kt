package com.tokopos

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.tokopos.receipt.BluetoothSppPrinter
import com.tokopos.receipt.Receipt58mmFormatter
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    private val printer = BluetoothSppPrinter()
    private val adapter: BluetoothAdapter? by lazy {
        getSystemService(BluetoothAdapter::class.java)
    }
    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) refreshPairedDevices()
    }

    private var devices by mutableStateOf<List<BluetoothDevice>>(emptyList())
    private var status by mutableStateOf("Pair RPP02N dari Settings Bluetooth, lalu tekan Muat ulang.")
    private var selected by mutableStateOf<BluetoothDevice?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val scope = rememberCoroutineScope()
            MaterialTheme {
                Scaffold(topBar = { TopAppBar(title = { Text("TokoPOS – Printer") }) }) { padding ->
                    Column(
                        Modifier.padding(padding).padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text("Printer target: RPP02N • Bluetooth Classic SPP • ESC/POS")
                        Button(
                            onClick = { requestBluetoothPermissionOrLoad() },
                            modifier = Modifier.fillMaxWidth()
                        ) { Text("Muat ulang printer yang sudah dipasangkan") }
                        Text(status)
                        LazyColumn(modifier = Modifier.weight(1f)) {
                            items(devices, key = { it.address }) { device ->
                                DeviceRow(
                                    device = device,
                                    selected = selected?.address == device.address,
                                    onSelect = { selected = device },
                                    onConnect = {
                                        scope.launch {
                                            status = "Menghubungkan ke ${device.name ?: device.address}..."
                                            val result = printer.connect(device)
                                            status = if (result.isSuccess) {
                                                "Terhubung ke ${device.name ?: device.address}"
                                            } else {
                                                "Gagal terhubung: ${result.exceptionOrNull()?.message}"
                                            }
                                        }
                                    }
                                )
                            }
                        }
                        Button(
                            onClick = {
                                scope.launch {
                                    val result = printer.print(Receipt58mmFormatter.testReceipt())
                                    status = if (result.isSuccess) "Perintah tes cetak terkirim."
                                    else "Cetak gagal: ${result.exceptionOrNull()?.message}"
                                }
                            },
                            enabled = printer.isConnected(),
                            modifier = Modifier.fillMaxWidth()
                        ) { Text("TES CETAK") }
                    }
                }
            }
        }
        requestBluetoothPermissionOrLoad()
    }

    private fun requestBluetoothPermissionOrLoad() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT)
                != PackageManager.PERMISSION_GRANTED
        ) {
            permissionLauncher.launch(Manifest.permission.BLUETOOTH_CONNECT)
        } else {
            refreshPairedDevices()
        }
    }

    @SuppressLint("MissingPermission")
    private fun refreshPairedDevices() {
        val bt = adapter
        if (bt == null) {
            status = "HP ini tidak memiliki Bluetooth."
            return
        }
        if (!bt.isEnabled) {
            status = "Aktifkan Bluetooth HP terlebih dahulu."
            return
        }
        devices = bt.bondedDevices.toList().sortedBy { it.name ?: it.address }
        status = if (devices.isEmpty()) {
            "Belum ada printer dipasangkan. Buka Settings > Bluetooth, pilih RPP02N, PIN biasanya 0000."
        } else {
            "Pilih RPP02N dari daftar perangkat yang sudah dipasangkan."
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        // Close socket on activity teardown; production app should manage this in a service/repository.
        kotlinx.coroutines.MainScope().launch { printer.disconnect() }
    }
}

@SuppressLint("MissingPermission")
@Composable
private fun DeviceRow(
    device: BluetoothDevice,
    selected: Boolean,
    onSelect: () -> Unit,
    onConnect: () -> Unit
) {
    Card(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(device.name ?: "Perangkat Bluetooth")
            Text(device.address, style = MaterialTheme.typography.bodySmall)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = onSelect) { Text(if (selected) "Dipilih" else "Pilih") }
                Button(onClick = onConnect) { Text("Hubungkan") }
            }
        }
    }
}
