package com.tokopos.receipt

object Receipt58mmFormatter {
    // RPP02N print width is 48 mm / 384 dots; keep text lines around 32 chars.
    fun testReceipt(storeName: String = "TOKOPOS"): ByteArray {
        val text = listOf(
            storeName,
            "TES KONEKSI BLUETOOTH",
            "PRINTER: RPP02N",
            "PAPER: 58 MM",
            "------------------------------",
            "Jika tulisan ini tercetak,",
            "koneksi ESC/POS berhasil.",
            "",
            "",
            ""
        ).joinToString("\n")
        val init = byteArrayOf(0x1B, 0x40)
        val left = byteArrayOf(0x1B, 0x61, 0x00)
        val boldOn = byteArrayOf(0x1B, 0x45, 0x01)
        val boldOff = byteArrayOf(0x1B, 0x45, 0x00)
        val feedAndCut = byteArrayOf(0x1B, 0x64, 0x03) // feed 3 lines; tear manually
        return init + left + boldOn + storeName.toByteArray(Charsets.US_ASCII) +
            "\n".toByteArray() + boldOff +
            text.substringAfter("\n").toByteArray(Charsets.US_ASCII) + feedAndCut
    }

    fun paymentCopy(
        storeName: String, source: String, method: String, amount: String,
        date: String, sender: String, recipient: String, reference: String
    ): ByteArray {
        val lines = listOf(
            storeName,
            "SALINAN BUKTI PEMBAYARAN",
            "------------------------------",
            "Sumber : $source",
            "Metode : $method",
            "Tanggal: $date",
            "Dari   : $sender",
            "Kepada : $recipient",
            "Nominal: $amount",
            "Ref    : $reference",
            "------------------------------",
            "Dicetak dari TokoPOS.",
            "Bukan verifikasi dana masuk.",
            "",
            ""
        ).joinToString("\n")
        return byteArrayOf(0x1B, 0x40, 0x1B, 0x61, 0x00) +
            lines.toByteArray(Charsets.UTF_8) + byteArrayOf(0x1B, 0x64, 0x03)
    }
}
