# TokoPOS Android – RPP02N Bluetooth starter

Target printer: RPP02N 58 mm, 48 mm effective print width (384 dots), ESC/POS.
Implementation uses Android Bluetooth Classic RFCOMM/SPP UUID and writes ESC/POS bytes.

## Pairing
1. Nyalakan printer.
2. Android Settings → Bluetooth → Pair new device.
3. Pilih `RPP02N` (nama bisa sedikit berbeda).
4. PIN pairing yang umum pada manual RPP02N adalah `0000`.
5. Buka TokoPOS, beri izin Nearby devices/Bluetooth, pilih printer, Hubungkan, lalu Tes Cetak.

## Build APK
- Buka folder project ini di Android Studio (JDK 17 recommended).
- Tunggu Gradle Sync.
- Build → Build Bundle(s) / APK(s) → Build APK(s).
- Output debug APK biasanya: `app/build/outputs/apk/debug/app-debug.apk`.

## Catatan
Ini starter pengujian koneksi printer, belum aplikasi kasir lengkap. Harus diuji pada HP dan unit RPP02N fisik. Sebagian varian/clone bisa menggunakan BLE atau profil berbeda; bila SPP gagal, periksa halaman self-test/manual dan revisi transport. Android 12+ memerlukan runtime permission `BLUETOOTH_CONNECT`.

Printer RPP02N tidak memiliki auto-cutter pada banyak varian; nota perlu disobek manual. Jangan anggap cetak berhasil sampai hasil fisik keluar.
